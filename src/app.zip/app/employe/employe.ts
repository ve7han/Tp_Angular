export interface Employe {
   id: number;
   name:string;
   service:string;
   salary:number;
}
