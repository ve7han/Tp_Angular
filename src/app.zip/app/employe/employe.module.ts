import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeRoutingModule } from './employe-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NavbarComponent } from './navbar/navbar.component';
import { AllComponent } from './all/all.component';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';


@NgModule({
  declarations: [
    NavbarComponent,
    AllComponent,
    AddComponent,
    EditComponent
  ],
  imports: [
    CommonModule,
    EmployeRoutingModule,
    ReactiveFormsModule
  ]
})
export class EmployeModule { }
