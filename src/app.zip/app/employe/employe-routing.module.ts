import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddComponent } from './add/add.component';
import { AllComponent } from './all/all.component';
import { EditComponent } from './edit/edit.component';

const routes: Routes = [
  { path: 'employe', redirectTo: 'employe/all', pathMatch: 'full' },
  { path: 'employe/all', component: AllComponent },
  { path: 'employe/add', component: AddComponent},
  { path: 'employe/edit', component: EditComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class EmployeRoutingModule {}
